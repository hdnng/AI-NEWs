# AI Pulse

Web tổng hợp tin tức AI theo thời gian thực + bảng xếp hạng mô hình AI theo nhiều tiêu chí.

Xây bằng Next.js 14 (App Router). Chạy được ngay, deploy miễn phí lên Vercel trong vài phút.

## Chạy thử ở máy local

```bash
npm install
npm run dev
```

Mở http://localhost:3000

## Deploy thật (khuyên dùng Vercel — miễn phí, có sẵn Cron)

1. Đẩy code này lên một repo GitHub (riêng tư hoặc công khai đều được).
2. Vào https://vercel.com → **Add New Project** → chọn repo vừa tạo → Deploy.
   Vercel tự nhận diện Next.js, không cần cấu hình gì thêm.
3. Xong. Trang sẽ có địa chỉ dạng `ten-du-an.vercel.app`, có thể gắn domain riêng trong tab Settings → Domains.

`vercel.json` đã cấu hình sẵn 1 cron job gọi `/api/news` mỗi 5 phút để cache luôn "ấm" — tin luôn sẵn sàng trước khi người dùng vào xem.

## Cách hoạt động — Tin tức

- `lib/rss-sources.js`: danh sách nguồn RSS. **Thêm nguồn mới chỉ cần thêm 1 dòng vào đây**, không phải sửa code parser.
- `lib/fetch-news.js`: gọi song song tất cả nguồn (`Promise.allSettled` — 1 nguồn lỗi không làm sập cả trang), parse cả RSS 2.0 lẫn Atom, gộp, loại trùng, sắp xếp theo thời gian mới nhất.
- Trang chủ (`app/page.js`) lấy dữ liệu lần đầu ở server (nhanh, tốt cho SEO), sau đó `components/NewsFeed.js` (client) tự động gọi lại `/api/news` mỗi 60 giây để cập nhật tin mới mà không cần tải lại trang — có huy hiệu "MỚI" cho tin dưới 15 phút.
- Muốn tin về nhanh hơn nữa: giảm số `120` trong `revalidate` (giây) ở `app/api/news/route.js` và `app/page.js`, và giảm `POLL_MS` trong `NewsFeed.js`. Lưu ý: gọi quá dày có thể khiến các trang nguồn chặn IP của bạn.

### Lưu ý pháp lý về RSS/scrape

RSS là kênh các trang tin **chủ động công khai** để được tổng hợp, nên dùng RSS là an toàn. Nếu sau này muốn tin nhanh hơn bằng cách cào trực tiếp HTML (scrape) thay vì RSS, hãy kiểm tra `robots.txt` và điều khoản sử dụng của từng trang — nhiều trang cấm scrape ngoài RSS.

## Cách hoạt động — Bảng xếp hạng

- `lib/leaderboard-data.js` đang chứa **dữ liệu mẫu** (model-a, model-b...) để bạn thấy rõ cấu trúc. Cột "Tổng hợp" được tự tính bằng cách chuẩn hoá các tiêu chí còn lại về thang 0–100 rồi lấy trung bình.
- Việc đầu tiên cần làm trước khi dùng thật: **thay `MODELS` bằng dữ liệu thật.**
- Có 2 cách cập nhật:
  1. **Thủ công** — sửa trực tiếp mảng `MODELS`, deploy lại. Đơn giản, đủ dùng nếu bạn cập nhật vài lần/tuần.
  2. **Tự động** — viết một hàm mới (ví dụ `lib/fetch-leaderboard.js`) gọi API/CSV công khai của các bảng xếp hạng có sẵn:
     - LMSYS Chatbot Arena (bình chọn người dùng, điểm Elo)
     - Hugging Face Open LLM Leaderboard (benchmark)
     rồi map dữ liệu về đúng cấu trúc `MODELS`, thay lời gọi trong `app/api/leaderboard/route.js`. Vì các bảng này thường cập nhật theo ngày/tuần chứ không theo phút, `revalidate = 300` (5 phút) trong `app/leaderboard/page.js` đã là quá đủ nhanh.
- Thêm/bớt tiêu chí: sửa mảng `CRITERIA`, thêm field tương ứng trong `scores` của mỗi model — UI (tab + thanh xếp hạng) tự cập nhật theo, không cần sửa component.

## Cấu trúc thư mục

```
app/
  page.js                  Trang chủ - tin tức
  leaderboard/page.js       Trang xếp hạng
  api/news/route.js         API tin tức (JSON)
  api/leaderboard/route.js  API xếp hạng (JSON)
  layout.js, globals.css    Layout & style chung
components/
  NewsFeed.js               Danh sách tin, tự poll mỗi 60s
  NewsCard.js                Thẻ 1 tin
  LeaderboardTabs.js         Tabs + thanh xếp hạng
  Nav.js                     Thanh điều hướng
lib/
  rss-sources.js             Danh sách nguồn RSS — sửa ở đây để thêm nguồn
  fetch-news.js               Lấy & chuẩn hoá RSS
  leaderboard-data.js         Dữ liệu & tính điểm xếp hạng
  time.js                     Định dạng "x phút trước"
vercel.json                  Cron giữ cache tin luôn mới
```

## Việc nên làm tiếp trước khi công bố chính thức

- [ ] Thay dữ liệu mẫu trong `lib/leaderboard-data.js` bằng số liệu thật.
- [ ] Rà lại danh sách nguồn RSS trong `lib/rss-sources.js` — thêm nguồn tiếng Việt/nguồn bạn quan tâm, bỏ nguồn không cần.
- [ ] Kiểm tra từng feed RSS còn hoạt động (một số trang đổi đường dẫn feed theo thời gian).
- [ ] Nếu lượng truy cập lớn, cân nhắc thêm cache layer (Vercel KV/Redis) thay vì fetch trực tiếp mỗi request.
