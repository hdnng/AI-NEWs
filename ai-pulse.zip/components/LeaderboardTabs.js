"use client";

import { useMemo, useState } from "react";

function formatScore(criterionId, value) {
  if (criterionId === "arenaElo") return Math.round(value);
  if (criterionId === "overall") return `${value.toFixed(1)}`;
  return value;
}

export default function LeaderboardTabs({ models, criteria }) {
  const [active, setActive] = useState(criteria[0].id);

  const ranked = useMemo(() => {
    const sorted = [...models].sort(
      (a, b) => b.scores[active] - a.scores[active]
    );
    const max = sorted[0]?.scores[active] || 1;
    return sorted.map((m, i) => ({ ...m, rank: i + 1, pct: (m.scores[active] / max) * 100 }));
  }, [models, active]);

  return (
    <div>
      <div className="flex flex-wrap gap-2 border-b border-line pb-5">
        {criteria.map((c) => (
          <button
            key={c.id}
            onClick={() => setActive(c.id)}
            className={`rounded-full px-4 py-1.5 font-mono text-xs uppercase tracking-wider transition-colors ${
              active === c.id
                ? "bg-pulseDim text-pulse"
                : "bg-surface text-muted hover:text-ink"
            }`}
          >
            {c.label}
          </button>
        ))}
      </div>

      <ol className="mt-6 space-y-3">
        {ranked.map((m) => (
          <li key={m.id} className="flex items-center gap-4">
            <span
              className={`w-6 shrink-0 text-right font-mono text-sm ${
                m.rank <= 3 ? "text-amber" : "text-muted"
              }`}
            >
              {m.rank}
            </span>

            <div className="min-w-0 flex-1">
              <div className="flex items-baseline justify-between gap-2">
                <span className="truncate font-display text-base font-medium text-ink">
                  {m.name}
                  <span className="ml-2 font-body text-xs font-normal text-muted">
                    {m.provider}
                  </span>
                </span>
                <span className="shrink-0 font-mono text-sm text-pulse">
                  {formatScore(active, m.scores[active])}
                </span>
              </div>
              <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-surface2">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-pulseDim to-pulse transition-all duration-500"
                  style={{ width: `${m.pct}%` }}
                />
              </div>
            </div>
          </li>
        ))}
      </ol>
    </div>
  );
}
