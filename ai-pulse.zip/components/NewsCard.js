"use client";

import { timeAgoVi } from "@/lib/time";

export default function NewsCard({ item, isFresh }) {
  return (
    <a
      href={item.link}
      target="_blank"
      rel="noopener noreferrer"
      className="group relative block animate-rise border-b border-line py-5 pl-6 transition-colors hover:bg-surface/60"
    >
      <span
        className={`absolute left-0 top-6 h-2 w-2 -translate-x-[3px] rounded-full ${
          isFresh ? "bg-pulse animate-pulseDot" : "bg-line"
        }`}
      />

      <div className="flex items-center gap-2 font-mono text-[11px] uppercase tracking-wider text-muted">
        <span className="text-pulse">{item.source}</span>
        <span>·</span>
        <time dateTime={item.publishedAt}>{timeAgoVi(item.publishedAt)}</time>
        {isFresh && (
          <span className="rounded-full bg-pulseDim px-2 py-0.5 text-pulse">
            MỚI
          </span>
        )}
      </div>

      <h3 className="mt-1.5 font-display text-lg font-medium leading-snug text-ink group-hover:text-pulse">
        {item.title}
      </h3>

      {item.summary && (
        <p className="mt-1.5 line-clamp-2 text-sm text-muted">{item.summary}</p>
      )}
    </a>
  );
}
