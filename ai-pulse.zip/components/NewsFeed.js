"use client";

import { useEffect, useRef, useState } from "react";
import NewsCard from "./NewsCard";
import { timeAgoVi } from "@/lib/time";

const POLL_MS = 60_000;
const FRESH_MS = 15 * 60_000;

export default function NewsFeed({ initialItems, initialFetchedAt }) {
  const [items, setItems] = useState(initialItems);
  const [fetchedAt, setFetchedAt] = useState(initialFetchedAt);
  const [newCount, setNewCount] = useState(0);
  const [, forceTick] = useState(0);
  const knownLinks = useRef(new Set(initialItems.map((i) => i.link)));

  // Tick lại mỗi 30s để nhãn "x phút trước" và badge MỚI luôn đúng mà không cần fetch lại.
  useEffect(() => {
    const t = setInterval(() => forceTick((n) => n + 1), 30_000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    let cancelled = false;

    async function poll() {
      try {
        const res = await fetch("/api/news", { cache: "no-store" });
        const data = await res.json();
        if (cancelled) return;

        const freshOnes = data.items.filter((i) => !knownLinks.current.has(i.link));
        if (freshOnes.length > 0) {
          freshOnes.forEach((i) => knownLinks.current.add(i.link));
          setItems(data.items);
          setNewCount((n) => n + freshOnes.length);
        }
        setFetchedAt(data.fetchedAt);
      } catch {
        // im lặng bỏ qua — vòng poll tiếp theo sẽ thử lại
      }
    }

    const id = setInterval(poll, POLL_MS);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, []);

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line pb-4 pt-2">
        <div className="flex items-center gap-2 font-mono text-xs text-muted">
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-pulseDot rounded-full bg-pulse" />
          </span>
          Cập nhật lúc {new Date(fetchedAt).toLocaleTimeString("vi-VN")} · tự động làm mới mỗi phút
        </div>
        {newCount > 0 && (
          <button
            onClick={() => setNewCount(0)}
            className="rounded-full bg-pulseDim px-3 py-1 font-mono text-xs text-pulse hover:brightness-125"
          >
            +{newCount} tin mới
          </button>
        )}
      </div>

      <div>
        {items.map((item) => (
          <NewsCard
            key={item.id}
            item={item}
            isFresh={Date.now() - new Date(item.publishedAt).getTime() < FRESH_MS}
          />
        ))}
      </div>

      {items.length === 0 && (
        <p className="py-10 text-center text-muted">
          Chưa lấy được tin nào — kiểm tra lại kết nối tới các nguồn RSS.
        </p>
      )}
    </div>
  );
}
