import { NextResponse } from "next/server";
import { getLeaderboard, CRITERIA } from "@/lib/leaderboard-data";

export async function GET() {
  const models = getLeaderboard();
  return NextResponse.json({ models, criteria: CRITERIA });
}
