import { NextResponse } from "next/server";
import { fetchAllNews } from "@/lib/fetch-news";

// Cho phép polling từ client mà vẫn tận dụng cache theo nguồn (xem fetch-news.js).
export const revalidate = 120;

export async function GET() {
  const items = await fetchAllNews();
  return NextResponse.json(
    { items, fetchedAt: new Date().toISOString() },
    { headers: { "Cache-Control": "s-maxage=120, stale-while-revalidate=60" } }
  );
}
