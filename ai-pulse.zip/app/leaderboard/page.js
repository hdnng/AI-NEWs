import { getLeaderboard, CRITERIA } from "@/lib/leaderboard-data";
import LeaderboardTabs from "@/components/LeaderboardTabs";

export const revalidate = 300;

export default async function LeaderboardPage() {
  const models = getLeaderboard();

  return (
    <div>
      <section className="border-b border-line py-10">
        <p className="font-mono text-xs uppercase tracking-[0.2em] text-amber">
          Bảng xếp hạng
        </p>
        <h1 className="mt-2 font-display text-4xl font-bold leading-tight text-ink sm:text-5xl">
          Ai đang dẫn đầu, theo từng tiêu chí
        </h1>
        <p className="mt-3 max-w-xl text-muted">
          Chọn một tiêu chí để xem thứ hạng thay đổi ra sao — dữ liệu mẫu, sẵn sàng
          để nối với nguồn thật (xem README).
        </p>
      </section>

      <section className="pt-6">
        <LeaderboardTabs models={models} criteria={CRITERIA} />
      </section>
    </div>
  );
}
