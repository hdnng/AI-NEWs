import { fetchAllNews } from "@/lib/fetch-news";
import NewsFeed from "@/components/NewsFeed";

export const revalidate = 120;

export default async function HomePage() {
  const items = await fetchAllNews();

  return (
    <div>
      <section className="border-b border-line py-10">
        <p className="font-mono text-xs uppercase tracking-[0.2em] text-pulse">
          Tổng hợp tin tức AI
        </p>
        <h1 className="mt-2 max-w-2xl font-display text-4xl font-bold leading-tight text-ink sm:text-5xl">
          Bắt tín hiệu AI ngay khi vừa phát ra
        </h1>
        <p className="mt-3 max-w-xl text-muted">
          Gom tin từ {new Set(items.map((i) => i.source)).size} nguồn uy tín, tự động
          làm mới liên tục — không cần tải lại trang.
        </p>
      </section>

      <section className="pt-2">
        <NewsFeed initialItems={items} initialFetchedAt={new Date().toISOString()} />
      </section>
    </div>
  );
}
